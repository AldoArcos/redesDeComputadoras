/***************************************************************
 * Name:      IpCalculatorApp.h
 * Purpose:   Defines Application Class
 * Author:    A. Aldo ()
 * Created:   2023-05-14
 * Copyright: A. Aldo ()
 * License:
 **************************************************************/

#ifndef IPCALCULATORAPP_H
#define IPCALCULATORAPP_H

#include <wx/app.h>

class IpCalculatorApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // IPCALCULATORAPP_H
