/***************************************************************
 * Name:      IpCalculatorMain.cpp
 * Purpose:   Code for Application Frame
 * Author:    A. Aldo ()
 * Created:   2023-05-14
 * Copyright: A. Aldo ()
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "IpCalculatorMain.h"
#include <wx/msgdlg.h>
#include <vector>
#include <iostream>
#include <sstream>
#include <vector>
#include <sstream>
#include <bitset>

//(*InternalHeaders(IpCalculatorFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(IpCalculatorFrame)
const long IpCalculatorFrame::ID_STATICTEXT1 = wxNewId();
const long IpCalculatorFrame::ID_TEXTCTRL1 = wxNewId();
const long IpCalculatorFrame::ID_TEXTCTRL2 = wxNewId();
const long IpCalculatorFrame::ID_CHOICE1 = wxNewId();
const long IpCalculatorFrame::ID_BUTTON1 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT2 = wxNewId();
const long IpCalculatorFrame::ID_CHECKLISTBOX1 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT3 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT8 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT4 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT12 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT5 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT6 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT7 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT9 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT10 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT11 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT16 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT13 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT14 = wxNewId();
const long IpCalculatorFrame::ID_STATICTEXT15 = wxNewId();
const long IpCalculatorFrame::ID_GRID1 = wxNewId();
const long IpCalculatorFrame::ID_PANEL1 = wxNewId();
const long IpCalculatorFrame::idMenuQuit = wxNewId();
const long IpCalculatorFrame::idMenuAbout = wxNewId();
const long IpCalculatorFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(IpCalculatorFrame,wxFrame)
    //(*EventTable(IpCalculatorFrame)
    //*)
END_EVENT_TABLE()

//global variables
int usedBits, availableBits, ipclass, aux, prefix, tthost, checkedBox = -1, flag;
std::vector<std::string> subnetHost;



IpCalculatorFrame::IpCalculatorFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(IpCalculatorFrame)
    wxBoxSizer* BoxSizer10;
    wxBoxSizer* BoxSizer11;
    wxBoxSizer* BoxSizer12;
    wxBoxSizer* BoxSizer13;
    wxBoxSizer* BoxSizer14;
    wxBoxSizer* BoxSizer15;
    wxBoxSizer* BoxSizer16;
    wxBoxSizer* BoxSizer17;
    wxBoxSizer* BoxSizer18;
    wxBoxSizer* BoxSizer19;
    wxBoxSizer* BoxSizer1;
    wxBoxSizer* BoxSizer20;
    wxBoxSizer* BoxSizer21;
    wxBoxSizer* BoxSizer2;
    wxBoxSizer* BoxSizer3;
    wxBoxSizer* BoxSizer4;
    wxBoxSizer* BoxSizer5;
    wxBoxSizer* BoxSizer6;
    wxBoxSizer* BoxSizer7;
    wxBoxSizer* BoxSizer8;
    wxBoxSizer* BoxSizer9;
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;

    Create(parent, wxID_ANY, _("IP Calculator"), wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    SetClientSize(wxSize(1200,500));
    SetMinSize(wxSize(-1,-1));
    SetMaxSize(wxSize(-1,-1));
    BoxSizer1 = new wxBoxSizer(wxHORIZONTAL);
    Panel1 = new wxPanel(this, ID_PANEL1, wxDefaultPosition, wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    BoxSizer2 = new wxBoxSizer(wxHORIZONTAL);
    BoxSizer3 = new wxBoxSizer(wxVERTICAL);
    BoxSizer5 = new wxBoxSizer(wxHORIZONTAL);
    StaticText1 = new wxStaticText(Panel1, ID_STATICTEXT1, _("IP Adress:"), wxDefaultPosition, wxSize(98,17), 0, _T("ID_STATICTEXT1"));
    BoxSizer5->Add(StaticText1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    TextCtrlIP = new wxTextCtrl(Panel1, ID_TEXTCTRL1, wxEmptyString, wxDefaultPosition, wxSize(227,34), 0, wxDefaultValidator, _T("ID_TEXTCTRL1"));
    BoxSizer5->Add(TextCtrlIP, 2, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer3->Add(BoxSizer5, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer6 = new wxBoxSizer(wxHORIZONTAL);
    TextCtrlOpc = new wxTextCtrl(Panel1, ID_TEXTCTRL2, wxEmptyString, wxDefaultPosition, wxSize(172,34), 0, wxDefaultValidator, _T("ID_TEXTCTRL2"));
    BoxSizer6->Add(TextCtrlOpc, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer7 = new wxBoxSizer(wxVERTICAL);
    Choice1 = new wxChoice(Panel1, ID_CHOICE1, wxDefaultPosition, wxSize(159,34), 0, 0, 0, wxDefaultValidator, _T("ID_CHOICE1"));
    BoxSizer7->Add(Choice1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Button1 = new wxButton(Panel1, ID_BUTTON1, _("Go"), wxDefaultPosition, wxSize(152,34), 0, wxDefaultValidator, _T("ID_BUTTON1"));
    BoxSizer7->Add(Button1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer6->Add(BoxSizer7, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer3->Add(BoxSizer6, 2, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer8 = new wxBoxSizer(wxVERTICAL);
    StaticText2 = new wxStaticText(Panel1, ID_STATICTEXT2, _("Subnet list"), wxDefaultPosition, wxSize(72,10), 0, _T("ID_STATICTEXT2"));
    StaticText2->SetMinSize(wxSize(-1,-1));
    StaticText2->SetMaxSize(wxSize(-1,-1));
    BoxSizer8->Add(StaticText2, 1, wxALL|wxALIGN_CENTER_HORIZONTAL, 5);
    CheckListBox1 = new wxCheckListBox(Panel1, ID_CHECKLISTBOX1, wxDefaultPosition, wxSize(348,288), 0, 0, 0, wxDefaultValidator, _T("ID_CHECKLISTBOX1"));
    BoxSizer8->Add(CheckListBox1, 8, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer3->Add(BoxSizer8, 4, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer2->Add(BoxSizer3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer4 = new wxBoxSizer(wxVERTICAL);
    BoxSizer14 = new wxBoxSizer(wxVERTICAL);
    BoxSizer9 = new wxBoxSizer(wxHORIZONTAL);
    BoxSizer17 = new wxBoxSizer(wxHORIZONTAL);
    StaticText3 = new wxStaticText(Panel1, ID_STATICTEXT3, _("Class:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT3"));
    BoxSizer17->Add(StaticText3, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticTextClass = new wxStaticText(Panel1, ID_STATICTEXT8, wxEmptyString, wxDefaultPosition, wxSize(140,17), 0, _T("ID_STATICTEXT8"));
    BoxSizer17->Add(StaticTextClass, 3, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer9->Add(BoxSizer17, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer13 = new wxBoxSizer(wxHORIZONTAL);
    StaticText4 = new wxStaticText(Panel1, ID_STATICTEXT4, _("NetMask:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT4"));
    BoxSizer13->Add(StaticText4, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticTextnetMask = new wxStaticText(Panel1, ID_STATICTEXT12, wxEmptyString, wxDefaultPosition, wxSize(190,17), 0, _T("ID_STATICTEXT12"));
    BoxSizer13->Add(StaticTextnetMask, 3, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer9->Add(BoxSizer13, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer14->Add(BoxSizer9, 1, wxALL|wxALIGN_LEFT, 5);
    BoxSizer10 = new wxBoxSizer(wxHORIZONTAL);
    BoxSizer12 = new wxBoxSizer(wxHORIZONTAL);
    StaticText5 = new wxStaticText(Panel1, ID_STATICTEXT5, _("Subnets:"), wxDefaultPosition, wxSize(93,17), 0, _T("ID_STATICTEXT5"));
    BoxSizer12->Add(StaticText5, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticTextSubnets = new wxStaticText(Panel1, ID_STATICTEXT6, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT6"));
    BoxSizer12->Add(StaticTextSubnets, 2, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer10->Add(BoxSizer12, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer18 = new wxBoxSizer(wxHORIZONTAL);
    StaticTextHost = new wxStaticText(Panel1, ID_STATICTEXT7, _("Host:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT7"));
    BoxSizer18->Add(StaticTextHost, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticText9 = new wxStaticText(Panel1, ID_STATICTEXT9, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT9"));
    BoxSizer18->Add(StaticText9, 2, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer10->Add(BoxSizer18, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer14->Add(BoxSizer10, 1, wxALL|wxALIGN_LEFT, 5);
    BoxSizer11 = new wxBoxSizer(wxHORIZONTAL);
    BoxSizer20 = new wxBoxSizer(wxHORIZONTAL);
    StaticText10 = new wxStaticText(Panel1, ID_STATICTEXT10, _("Subnet Mask:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT10"));
    BoxSizer20->Add(StaticText10, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticTextSubnetMask = new wxStaticText(Panel1, ID_STATICTEXT11, wxEmptyString, wxDefaultPosition, wxSize(122,17), 0, _T("ID_STATICTEXT11"));
    BoxSizer20->Add(StaticTextSubnetMask, 2, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer11->Add(BoxSizer20, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer21 = new wxBoxSizer(wxHORIZONTAL);
    StaticTextIPType = new wxStaticText(Panel1, ID_STATICTEXT16, wxEmptyString, wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT16"));
    BoxSizer21->Add(StaticTextIPType, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer11->Add(BoxSizer21, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer14->Add(BoxSizer11, 1, wxALL|wxALIGN_LEFT, 5);
    BoxSizer4->Add(BoxSizer14, 3, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer15 = new wxBoxSizer(wxVERTICAL);
    BoxSizer16 = new wxBoxSizer(wxVERTICAL);
    StaticText13 = new wxStaticText(Panel1, ID_STATICTEXT13, _("Host list"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT13"));
    BoxSizer16->Add(StaticText13, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer19 = new wxBoxSizer(wxHORIZONTAL);
    StaticText14 = new wxStaticText(Panel1, ID_STATICTEXT14, _("Subnet:"), wxDefaultPosition, wxDefaultSize, 0, _T("ID_STATICTEXT14"));
    BoxSizer19->Add(StaticText14, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    StaticTextSelectedSubnet = new wxStaticText(Panel1, ID_STATICTEXT15, wxEmptyString, wxDefaultPosition, wxSize(165,17), 0, _T("ID_STATICTEXT15"));
    BoxSizer19->Add(StaticTextSelectedSubnet, 3, wxALL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer16->Add(BoxSizer19, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer15->Add(BoxSizer16, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    GridHost = new wxGrid(Panel1, ID_GRID1, wxDefaultPosition, wxSize(355,374), 0, _T("ID_GRID1"));
    BoxSizer15->Add(GridHost, 5, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer4->Add(BoxSizer15, 10, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    BoxSizer2->Add(BoxSizer4, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    Panel1->SetSizer(BoxSizer2);
    BoxSizer2->Fit(Panel1);
    BoxSizer2->SetSizeHints(Panel1);
    BoxSizer1->Add(Panel1, 1, wxALL|wxALIGN_CENTER_HORIZONTAL|wxALIGN_CENTER_VERTICAL, 5);
    SetSizer(BoxSizer1);
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);
    SetSizer(BoxSizer1);
    Layout();

    Connect(ID_TEXTCTRL1,wxEVT_COMMAND_TEXT_UPDATED,(wxObjectEventFunction)&IpCalculatorFrame::OnTextCtrlIPText);
    Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&IpCalculatorFrame::OnButton1Click);
    Connect(ID_CHECKLISTBOX1,wxEVT_COMMAND_CHECKLISTBOX_TOGGLED,(wxObjectEventFunction)&IpCalculatorFrame::OnCheckListBox1Toggled);
    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&IpCalculatorFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&IpCalculatorFrame::OnAbout);
    Connect(wxID_ANY,wxEVT_CLOSE_WINDOW,(wxObjectEventFunction)&IpCalculatorFrame::OnClose);
    //*)

    Choice1->Append("Host");
    Choice1->Append("Subnet");
    Choice1->Append("Prefix");

}
//declaration of functions
std::vector<int> IPStringToInt(const std::string& IPAdress);
void printInfo(int IPValue,wxStaticText* StaticTextClass,wxStaticText* StaticTextnetMask);
void printSubnets(int subnetBits, wxCheckListBox* CheckListBoxSubnet, std::vector<int>& vec, int cont, int totalSubnets);
int getUsedBits(int reqHosts);
int setInfo(int textOpc,  int totalHost,int totalSubnets, std::string opc, wxStaticText * StaticTextSubnets,  wxStaticText * StaticText9);
std::vector<std::string> obtenerSubredes(const std::string& direccionIP, int prefijo, int totalSubnets);
std::vector<std::string> obtenerHosts(const std::string& subred);
std::string GetSubnetMask(int prefixLength);
bool isPrivate(std::vector<int>& ipValues, std::string& opc);
std::vector<std::string> obtenerHostsSubred(const std::string& ipSubred, int numHosts);


IpCalculatorFrame::~IpCalculatorFrame()
{
    //(*Destroy(IpCalculatorFrame)
    //*)
}

void IpCalculatorFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void IpCalculatorFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void IpCalculatorFrame::OnButton1Click(wxCommandEvent& event)
{
    usedBits = 0, availableBits = 32;
    int totalSubnets, totalHost, textOpc, i = 0;
    wxString wxIP = TextCtrlIP -> GetValue(), formatedText;
    wxString wxOpc = Choice1 -> GetStringSelection();
    textOpc = wxAtoi(TextCtrlOpc -> GetValue());
    std::string ip = wxIP.ToStdString(), opc = wxOpc.ToStdString();
    std::vector<int> IPValues = IPStringToInt(ip);

    CheckListBox1 -> Clear();
    GridHost -> ClearGrid();

    printInfo(IPValues[0], StaticTextClass, StaticTextnetMask);

    flag = isPrivate(IPValues, opc);
    if(flag)
    {
        StaticTextIPType -> SetLabelMarkup("<b>Private</b>");
        //StaticTextClass -> SetLabelMarkup("<b>Private</b>");
    }
    else
    {
        StaticTextIPType -> SetLabelMarkup("<b>Public</b>");
    }

    totalSubnets = setInfo(textOpc, totalHost, totalSubnets, opc, StaticTextSubnets, StaticText9);
    GridHost -> CreateGrid(tthost + 1, 1);
    std::vector<std::string> subredes = obtenerSubredes(ip, prefix, totalSubnets);

    for (const auto& subred : subredes) {
        formatedText = wxString::Format("%s", subred);
        CheckListBox1 -> Append(formatedText);
        i++;
    }
    std::string subnetMask = GetSubnetMask(prefix);
    formatedText = wxString::Format("<b>%s</b>", subnetMask);
    //StaticTextSubnetMask -> SetLabelMarkup(formatedText);

}

void IpCalculatorFrame::OnClose(wxCloseEvent& event)
{
    Close();
}

void IpCalculatorFrame::OnTextCtrlIPText(wxCommandEvent& event)
{
}

std::vector<int> IPStringToInt(const std::string& IPAdress)
{
    std::vector<int> IPValues;
    std::stringstream ss(IPAdress);
    std::string segment;

    while (std::getline(ss, segment, '.')) {
        int valor = std::stoi(segment);
        IPValues.push_back(valor);
    }

    return IPValues;
}

void printInfo(int IPValues,wxStaticText* StaticTextClass,wxStaticText* StaticTextnetMask)
{
    if(IPValues <= 126)
    {
        usedBits = 8;
        ipclass = 1;
        StaticTextClass->SetLabelMarkup("<b>A</b>");
        StaticTextnetMask->SetLabelMarkup("<b>255.0.0.0</b>");
    }
    else if(IPValues >= 128 && IPValues <= 191)
    {
        usedBits = 16;
        ipclass = 2;
        StaticTextClass->SetLabelMarkup("<b>B</b>");
        StaticTextnetMask->SetLabelMarkup("<b>255.255.0.0</b>");
    }
    else if(IPValues >= 192 && IPValues <= 223)
    {
        usedBits = 24;
        ipclass = 3;
        StaticTextClass->SetLabelMarkup("<b>C</b>");
        StaticTextnetMask->SetLabelMarkup("<b>255.255.255.0</b>");
    }
    else if(IPValues >= 224 && IPValues <= 239)
    {
        usedBits = 32;
        ipclass = 4;
        StaticTextClass->SetLabelMarkup("<b>D</b>");
        StaticTextnetMask->SetLabelMarkup("<b>255.255.255.255</b>");
    }
    else if(IPValues>= 240 && IPValues <= 254)
    {
        usedBits = 32;
        ipclass = 5;
        StaticTextClass->SetLabelMarkup("<b>E</b>");
        StaticTextnetMask->SetLabelMarkup("<b>255.255.255.255</b>");
    }
    else
    {
        StaticTextClass->SetLabelMarkup("<b>INVALID</b>");
    }
}

int setInfo(int textOpc, int totalHost, int totalSubnets, std::string opc, wxStaticText * StaticTextSubnets,  wxStaticText * StaticText9)
{
    wxString formatedText;

    if(opc == "Host")
    {
        textOpc = getUsedBits(textOpc);
        prefix = 32 - textOpc;
        usedBits = usedBits + textOpc;
        availableBits = availableBits - usedBits;
        aux = availableBits;
        if(availableBits > 0)
        {
            totalSubnets = (pow(2, availableBits)) - 2;
            formatedText = wxString::Format("<b>%d</b>", totalSubnets);
            StaticTextSubnets -> SetLabelMarkup(formatedText);
        }
        else
        {
            formatedText = wxString::Format("<b>0</b>");
            StaticTextSubnets -> SetLabelMarkup(formatedText);
        }
        totalHost = (pow(2, textOpc)) - 2;
        formatedText = wxString::Format("<b>%d</b>", totalHost);
        StaticText9 -> SetLabelMarkup(formatedText);

    }
    else if(opc == "Subnet")
    {
        prefix = usedBits + textOpc;
        textOpc = getUsedBits(textOpc);
        aux = textOpc;
        usedBits = usedBits + textOpc;
        availableBits = availableBits - usedBits;
        if(availableBits > 0)
        {
            totalHost = (pow(2, availableBits)) - 2;
            formatedText = wxString::Format("<b>%d</b>", totalHost);
            StaticText9 -> SetLabelMarkup(formatedText);
        }
        else
        {
            formatedText = wxString::Format("<b>0</b>");
            StaticText9 -> SetLabelMarkup(formatedText);
        }
        totalSubnets = (pow(2, textOpc)) - 2;
        formatedText = wxString::Format("<b>%d</b>", totalSubnets);
        StaticTextSubnets -> SetLabelMarkup(formatedText);
    }
    else if(opc == "Prefix")
    {
        prefix = textOpc;
        availableBits = availableBits - prefix;
        if(availableBits > 0)
        {
            totalHost = (pow(2, availableBits)) - 2;
            formatedText = wxString::Format("<b>%d</b>", totalHost);
            StaticText9 -> SetLabelMarkup(formatedText);
        }
        else
        {
            formatedText = wxString::Format("<b>0</b>");
            StaticText9 -> SetLabelMarkup(formatedText);
        }

        aux = textOpc - usedBits;
        totalSubnets = pow(2, (aux)) - 2;


        formatedText = wxString::Format("<b>%d</b>", totalSubnets);
        StaticTextSubnets -> SetLabelMarkup(formatedText);

    }
    tthost = totalHost;
    return totalSubnets;

}

int getUsedBits(int reqHosts)
{
    int i = 0;
    while((pow(2, i) - 2) < reqHosts)
    {
        i++;
    }
    return i;
}


std::vector<std::string> obtenerSubredes(const std::string& direccionIP, int prefijo, int totalSubnets) {
    std::vector<std::string> subredes;

    // Parsear la dirección IP
    std::stringstream ss(direccionIP);
    std::string segment;
    std::vector<int> octetos;

    while (std::getline(ss, segment, '.')) {
        octetos.push_back(std::stoi(segment));
    }

    // Calcular la cantidad de subredes posibles
    int numSubredes = totalSubnets + 1;

    // Calcular el tamaño de cada subred
    int tamSubred = 1 << (32 - prefijo);

    // Calcular y almacenar las subredes
    for (int i = 0; i < numSubredes; ++i) {
        std::stringstream subredSS;

        for (int j = 0; j < 4; ++j) {
            if (j > 0) {
                subredSS << ".";
            }
            subredSS << octetos[j];

            if (j == 3) {
                subredSS << "/" << prefijo;
            }
        }

        subredes.push_back(subredSS.str());

        // Actualizar el último octeto de la dirección IP para la próxima subred
int carry = tamSubred / 256; // Cálculo del acarreo
octetos[3] = (octetos[3] + tamSubred) % 256;

// Ajustar los octetos y llevar el acarreo si es necesario
for (int j = 2; j >= 0; --j) {
    octetos[j] = (octetos[j] + carry) % 256;
    carry = (octetos[j] + carry) / 256;
}
    }

    return subredes;
}


std::vector<std::string> obtenerHosts(const std::string& subred) {
    std::vector<std::string> hosts;

    std::stringstream ss(subred);
    std::string segment;
    std::vector<int> octetos;
    int prefijo = 0;

    while (std::getline(ss, segment, '.')) {
        if (segment.find('/') != std::string::npos) {
            std::string prefijoStr = segment.substr(segment.find('/') + 1);
            prefijo = std::stoi(prefijoStr);
        } else {
            octetos.push_back(std::stoi(segment));
        }
    }

    // Calcular la cantidad de hosts posibles
    int numHosts = (1 << (32 - prefijo)) - 2;

    // Generar y almacenar los hosts
    for (int i = 1; i <= numHosts; ++i) {
        std::stringstream hostSS;

        // Establecer los octetos de la dirección IP del host
        for (int j = 0; j < 4; ++j) {
            if (j > 0) {
                hostSS << ".";
            }
            hostSS << octetos[j];
        }

        hosts.push_back(hostSS.str());

        // Actualizar el último octeto de la dirección IP para el próximo host
        octetos[3] += 1;

        // Ajustar los octetos y llevar el acarreo si es necesario
        for (int j = 3; j > 0; --j) {
            if (octetos[j] > 255) {
                octetos[j] -= 256;
                octetos[j - 1] += 1;
            }
        }
    }

    return hosts;
}

void IpCalculatorFrame::OnCheckListBox1Toggled(wxCommandEvent& event)
{
    GridHost -> ClearGrid();

    int i = 0;
    //if(checkedBox>=0)
        CheckListBox1->Check(checkedBox, false);

    checkedBox = CheckListBox1 -> GetSelection();

    wxString sr = event.GetString(), formatedText;
    std::string subred = sr.ToStdString();
    std::vector<std::string> hosts = obtenerHosts(subred);
    //std::vector<std::string> hosts = obtenerHostsSubred(subred, tthost + 1);
    formatedText = wxString::Format("<b>%s</b>", subred);
    //StaticTextSelectedSubnet -> SetLabelMarkup(formatedText);

    GridHost->SetColSize(0, 250);
    GridHost->SetColLabelValue(0, "Host");

    for (const auto& host : hosts) {
        //std::cout << host << std::endl;
        formatedText = wxString::Format("%s", host);
        GridHost->SetCellValue(i, 0, formatedText);
        i++;
    }

    //GridHost->AutoSizeColLabelSize(1);

    GridHost->EnableEditing(false);
}

std::string GetSubnetMask(int prefixLength)
{
    std::bitset<32> bits;
    for (int i = 0; i < prefixLength; ++i)
    {
        bits.set(i, true);
    }

    std::string subnetMask;
    for (int i = 0; i < 4; ++i)
    {
        std::bitset<8> octet(bits.to_string().substr(i * 8, 8));
        subnetMask += std::to_string(octet.to_ulong());
        if (i < 3)
        {
            subnetMask += ".";
        }
    }

    return subnetMask;
}

bool isPrivate(std::vector<int>& ipValues, std::string& opc)
{
    flag = 0;
    int textOpc = wxAtoi(opc);

    if(ipValues[0] == 10)
    {
        //privType = 1;
        flag++;
        //privSubnet = textOpc - 8;
    }
    else if(ipValues[0] == 172 && ipValues[1] >= 16 && ipValues[1] <= 31)
    {
       // privType = 2;
        flag++;
        //privSubnet = textOpc - 11;
    }

    else if(ipValues[0] == 192 && ipValues[1] == 168)
    {
       // privType = 3;
        flag++;
        //privSubnet = textOpc - 16;
    }

    return flag;
}

std::vector<std::string> obtenerHostsSubred(const std::string& ipSubred, int numHosts) {
    std::vector<std::string> hosts;

    // Obtener los octetos de la IP
    std::istringstream iss(ipSubred);
    std::string octeto;
    std::vector<int> octetos;
    while (std::getline(iss, octeto, '.')) {
        octetos.push_back(std::stoi(octeto));
    }

    // Calcular el rango de hosts
    int minHost = octetos[3] + 1;  // El primer host disponible en la subred
    int maxHost = minHost + numHosts - 2;  // El último host disponible en la subred

    // Validar el rango de hosts
    if (minHost < 1 || maxHost > 254) {
        std::cout << "El rango de hosts no es válido para la subred especificada." << std::endl;
        return hosts;
    }

    // Generar los hosts y almacenarlos en el vector
    for (int i = minHost; i <= maxHost; i++) {
        std::ostringstream host;
        host << octetos[0] << "." << octetos[1] << "." << octetos[2] << "." << i;
        hosts.push_back(host.str());
    }

    return hosts;
}
