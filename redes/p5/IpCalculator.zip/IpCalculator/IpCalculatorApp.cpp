/***************************************************************
 * Name:      IpCalculatorApp.cpp
 * Purpose:   Code for Application Class
 * Author:    A. Aldo ()
 * Created:   2023-05-14
 * Copyright: A. Aldo ()
 * License:
 **************************************************************/

#include "wx_pch.h"
#include "IpCalculatorApp.h"

//(*AppHeaders
#include "IpCalculatorMain.h"
#include <wx/image.h>
//*)

IMPLEMENT_APP(IpCalculatorApp);

bool IpCalculatorApp::OnInit()
{
    //(*AppInitialize
    bool wxsOK = true;
    wxInitAllImageHandlers();
    if ( wxsOK )
    {
    	IpCalculatorFrame* Frame = new IpCalculatorFrame(0);
    	Frame->Show();
    	SetTopWindow(Frame);
    }
    //*)
    return wxsOK;

}
