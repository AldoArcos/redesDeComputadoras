/***************************************************************
 * Name:      IpCalculatorMain.h
 * Purpose:   Defines Application Frame
 * Author:    A. Aldo ()
 * Created:   2023-05-14
 * Copyright: A. Aldo ()
 * License:
 **************************************************************/

#ifndef IPCALCULATORMAIN_H
#define IPCALCULATORMAIN_H

//(*Headers(IpCalculatorFrame)
#include <wx/button.h>
#include <wx/checklst.h>
#include <wx/choice.h>
#include <wx/frame.h>
#include <wx/grid.h>
#include <wx/menu.h>
#include <wx/panel.h>
#include <wx/sizer.h>
#include <wx/stattext.h>
#include <wx/statusbr.h>
#include <wx/textctrl.h>
//*)

class IpCalculatorFrame: public wxFrame
{
    public:

        IpCalculatorFrame(wxWindow* parent,wxWindowID id = -1);
        virtual ~IpCalculatorFrame();

    private:

        //(*Handlers(IpCalculatorFrame)
        void OnQuit(wxCommandEvent& event);
        void OnAbout(wxCommandEvent& event);
        void OnButton1Click(wxCommandEvent& event);
        void OnClose(wxCloseEvent& event);
        void OnTextCtrlIPText(wxCommandEvent& event);
        void OnCheckListBox1Toggled(wxCommandEvent& event);
        //*)

        //(*Identifiers(IpCalculatorFrame)
        static const long ID_STATICTEXT1;
        static const long ID_TEXTCTRL1;
        static const long ID_TEXTCTRL2;
        static const long ID_CHOICE1;
        static const long ID_BUTTON1;
        static const long ID_STATICTEXT2;
        static const long ID_CHECKLISTBOX1;
        static const long ID_STATICTEXT3;
        static const long ID_STATICTEXT8;
        static const long ID_STATICTEXT4;
        static const long ID_STATICTEXT12;
        static const long ID_STATICTEXT5;
        static const long ID_STATICTEXT6;
        static const long ID_STATICTEXT7;
        static const long ID_STATICTEXT9;
        static const long ID_STATICTEXT10;
        static const long ID_STATICTEXT11;
        static const long ID_STATICTEXT16;
        static const long ID_STATICTEXT13;
        static const long ID_STATICTEXT14;
        static const long ID_STATICTEXT15;
        static const long ID_GRID1;
        static const long ID_PANEL1;
        static const long idMenuQuit;
        static const long idMenuAbout;
        static const long ID_STATUSBAR1;
        //*)

        //(*Declarations(IpCalculatorFrame)
        wxButton* Button1;
        wxCheckListBox* CheckListBox1;
        wxChoice* Choice1;
        wxGrid* GridHost;
        wxPanel* Panel1;
        wxStaticText* StaticText10;
        wxStaticText* StaticText13;
        wxStaticText* StaticText14;
        wxStaticText* StaticText1;
        wxStaticText* StaticText2;
        wxStaticText* StaticText3;
        wxStaticText* StaticText4;
        wxStaticText* StaticText5;
        wxStaticText* StaticText9;
        wxStaticText* StaticTextClass;
        wxStaticText* StaticTextHost;
        wxStaticText* StaticTextIPType;
        wxStaticText* StaticTextSelectedSubnet;
        wxStaticText* StaticTextSubnetMask;
        wxStaticText* StaticTextSubnets;
        wxStaticText* StaticTextnetMask;
        wxStatusBar* StatusBar1;
        wxTextCtrl* TextCtrlIP;
        wxTextCtrl* TextCtrlOpc;
        //*)

        DECLARE_EVENT_TABLE()
};

#endif // IPCALCULATORMAIN_H
